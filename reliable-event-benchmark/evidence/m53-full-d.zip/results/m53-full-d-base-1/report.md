# Benchmark m53-full-d-base-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3725.6748361401637
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.395644292086324; steady 20–80% event timestamps: 48.92026510365292
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100391.5, 'p95_ms': 190128.54999999935, 'p99_ms': 198073.2000000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16435.5096, 'max_ms': 169.8864, 'mean_ms': 1.6435509600000002}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1003657215.0, 'max_ms': 200052.0, 'mean_ms': 100365.7215}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.079166666666667 / 13.43; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 428560384.0; MySQL block I/O first/last: ['465MB / 2.94GB', '465MB / 3.31GB']; Broker block I/O first/last: ['772MB / 2.12GB', '772MB / 2.29GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
