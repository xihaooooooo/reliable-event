# Benchmark m53-full-d-base-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3499.6921320831407
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.40784695425328; steady 20–80% event timestamps: 48.870465983679985
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100182.5, 'p95_ms': 189989.14999999932, 'p99_ms': 197969.1100000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16543.4165, 'max_ms': 192.3591, 'mean_ms': 1.6543416499999999}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1001641962.0, 'max_ms': 199934.0, 'mean_ms': 100164.1962}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 9.87 / 12.43; max connected/running threads: 33.0 / 8.0
- Publisher memory max (bytes): 367382528.0; MySQL block I/O first/last: ['465MB / 3.73GB', '466MB / 4.09GB']; Broker block I/O first/last: ['772MB / 2.89GB', '772MB / 3.66GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
