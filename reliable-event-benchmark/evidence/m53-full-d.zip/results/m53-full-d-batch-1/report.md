# Benchmark m53-full-d-batch-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3040.7225729864635
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 99.08642317829612; steady 20–80% event timestamps: 97.41724971997208
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 49222.0, 'p95_ms': 93173.49999999942, 'p99_ms': 97064.25000000017}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16994.8817, 'max_ms': 157.6778, 'mean_ms': 1.6994881700000002}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 492378667.0, 'max_ms': 98016.0, 'mean_ms': 49237.8667}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 18.67684210526316 / 24.62; max connected/running threads: 33.0 / 10.0
- Publisher memory max (bytes): 343191552.0; MySQL block I/O first/last: ['500MB / 15.4GB', '500MB / 15.8GB']; Broker block I/O first/last: ['780MB / 7.45GB', '780MB / 7.95GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
