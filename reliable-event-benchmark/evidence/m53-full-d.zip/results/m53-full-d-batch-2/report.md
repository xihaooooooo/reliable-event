# Benchmark m53-full-d-batch-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3108.19525098226
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 98.9129467155956; steady 20–80% event timestamps: 97.64391942464773
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 49307.5, 'p95_ms': 93373.3999999994, 'p99_ms': 97298.21000000018}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16455.1211, 'max_ms': 158.4264, 'mean_ms': 1.64551211}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 493490220.0, 'max_ms': 98270.0, 'mean_ms': 49349.022}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 18.492105263157896 / 23.95; max connected/running threads: 33.0 / 13.0
- Publisher memory max (bytes): 331980800.0; MySQL block I/O first/last: ['500MB / 17.2GB', '500MB / 17.5GB']; Broker block I/O first/last: ['780MB / 10.4GB', '780MB / 10.9GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
