# Benchmark m53-full-d-batch-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3106.275758015154
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 98.89925133266742; steady 20–80% event timestamps: 97.84292305936445
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 49343.5, 'p95_ms': 93361.84999999941, 'p99_ms': 97278.26000000018}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 17346.0608, 'max_ms': 159.6553, 'mean_ms': 1.7346060799999998}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 494268168.0, 'max_ms': 98258.0, 'mean_ms': 49426.8168}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 19.045555555555556 / 24.89; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 395112448.0; MySQL block I/O first/last: ['500MB / 18.9GB', '500MB / 19.2GB']; Broker block I/O first/last: ['780MB / 12.9GB', '780MB / 13.1GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
