# Benchmark m53-full-d-h100000-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3772.0553016501312
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.256230913210516; steady 20–80% event timestamps: 48.8402376495483
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100913.5, 'p95_ms': 190698.89999999932, 'p99_ms': 198670.1700000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16351.8989, 'max_ms': 181.484, 'mean_ms': 1.63518989}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1008519334.0, 'max_ms': 200640.0, 'mean_ms': 100851.9334}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.353611111111112 / 13.06; max connected/running threads: 33.0 / 10.0
- Publisher memory max (bytes): 363896832.0; MySQL block I/O first/last: ['467MB / 5.07GB', '467MB / 5.68GB']; Broker block I/O first/last: ['772MB / 4.52GB', '772MB / 5.27GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
