# Benchmark m53-full-d-h100000-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3818.8958892220794
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.272734439670465; steady 20–80% event timestamps: 48.81560537532945
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100858.5, 'p95_ms': 190683.94999999934, 'p99_ms': 198660.2400000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16602.8377, 'max_ms': 216.984, 'mean_ms': 1.66028377}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1007918128.0, 'max_ms': 200646.0, 'mean_ms': 100791.8128}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.17 / 13.44; max connected/running threads: 33.0 / 7.0
- Publisher memory max (bytes): 426954752.0; MySQL block I/O first/last: ['468MB / 5.89GB', '468MB / 6.51GB']; Broker block I/O first/last: ['772MB / 5.29GB', '772MB / 6.1GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
