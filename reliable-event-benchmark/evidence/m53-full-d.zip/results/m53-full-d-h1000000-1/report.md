# Benchmark m53-full-d-h1000000-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3722.6051624790584
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.3264473612817; steady 20–80% event timestamps: 48.937818552497454
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100671.5, 'p95_ms': 190401.34999999934, 'p99_ms': 198383.0400000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 17772.9451, 'max_ms': 159.0448, 'mean_ms': 1.7772945100000002}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1006344721.0, 'max_ms': 200358.0, 'mean_ms': 100634.4721}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 11.55942857142857 / 15.39; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 364797952.0; MySQL block I/O first/last: ['481MB / 8.52GB', '484MB / 9.35GB']; Broker block I/O first/last: ['772MB / 6.12GB', '772MB / 6.7GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
