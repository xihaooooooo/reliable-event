# Benchmark m53-full-d-h1000000-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3580.080347027212
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.220107398274344; steady 20–80% event timestamps: 48.91348646137293
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 101046.0, 'p95_ms': 190667.54999999935, 'p99_ms': 198647.3100000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 17271.2203, 'max_ms': 178.8459, 'mean_ms': 1.72712203}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1009876957.0, 'max_ms': 200645.0, 'mean_ms': 100987.6957}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 11.765428571428572 / 17.32; max connected/running threads: 33.0 / 10.0
- Publisher memory max (bytes): 356552704.0; MySQL block I/O first/last: ['494MB / 14.2GB', '499MB / 15.1GB']; Broker block I/O first/last: ['775MB / 6.96GB', '775MB / 7.2GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
