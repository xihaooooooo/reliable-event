# Benchmark m53-full-d-multi-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3738.9401682455778
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 98.10750620529977; steady 20–80% event timestamps: 98.62928144106239
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 49970.0, 'p95_ms': 94606.0, 'p99_ms': 98572.01}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 19600.8708, 'max_ms': 180.543, 'mean_ms': 1.96008708}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 498179660.0, 'max_ms': 99554.0, 'mean_ms': 49817.966}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 17.819473684210525 / 22.58; max connected/running threads: 49.0 / 8.0
- Publisher memory max (bytes): 660271104.0; MySQL block I/O first/last: ['500MB / 16.5GB', '500MB / 16.8GB']; Broker block I/O first/last: ['780MB / 9.63GB', '780MB / 10.1GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
