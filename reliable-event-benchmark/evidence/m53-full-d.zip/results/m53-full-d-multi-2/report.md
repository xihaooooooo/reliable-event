# Benchmark m53-full-d-multi-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3637.007055975539
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 97.89621043769395; steady 20–80% event timestamps: 98.60011172817192
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 50269.0, 'p95_ms': 94768.0, 'p99_ms': 98728.0}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 21261.3598, 'max_ms': 192.0984, 'mean_ms': 2.12613598}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 502720740.0, 'max_ms': 99709.0, 'mean_ms': 50272.074}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 20.663888888888888 / 24.04; max connected/running threads: 49.0 / 8.0
- Publisher memory max (bytes): 693485568.0; MySQL block I/O first/last: ['500MB / 18.2GB', '500MB / 18.5GB']; Broker block I/O first/last: ['780MB / 12.3GB', '780MB / 12.7GB']
- InnoDB row lock waits/time deltas: 8.0 / 38.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
