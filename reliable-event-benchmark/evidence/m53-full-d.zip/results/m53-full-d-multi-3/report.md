# Benchmark m53-full-d-multi-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3442.442346750126
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 96.95559433779329; steady 20–80% event timestamps: 98.45936766805033
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 51083.0, 'p95_ms': 95626.0, 'p99_ms': 99572.04000000001}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 21997.942, 'max_ms': 239.8114, 'mean_ms': 2.1997942}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 512240103.0, 'max_ms': 100556.0, 'mean_ms': 51224.0103}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 17.646315789473686 / 23.44; max connected/running threads: 49.0 / 4.0
- Publisher memory max (bytes): 726130688.0; MySQL block I/O first/last: ['500MB / 20GB', '500MB / 20.3GB']; Broker block I/O first/last: ['792MB / 13.8GB', '792MB / 14.1GB']
- InnoDB row lock waits/time deltas: 80.0 / 232.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
