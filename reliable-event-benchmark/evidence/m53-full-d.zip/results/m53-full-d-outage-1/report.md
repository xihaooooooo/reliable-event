# Benchmark m53-full-d-outage-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3774.871210831465
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 46.75803186092291; steady 20–80% event timestamps: 49.366974061978134
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 111545.0, 'p95_ms': 201584.15, 'p99_ms': 209537.0}
- Sender attempts: {'failure': 16, 'success': 10000}; failure types: {'RESULT_UNKNOWN': 16}; failure rate: 0.001597444089456869
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 50103.8819, 'max_ms': 4339.9024, 'mean_ms': 5.0103881900000005}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 16, 'total_ms': 81140.2787, 'max_ms': 5138.436, 'mean_ms': 5071.26741875}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1118663754.0, 'max_ms': 214126.0, 'mean_ms': 111866.3754}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.23972972972973 / 13.37; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 425934848.0; MySQL block I/O first/last: ['500MB / 20.3GB', '500MB / 20.7GB']; Broker block I/O first/last: ['792MB / 14.1GB', '792MB / 14.5GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): [{'epoch_ms': '1790400207597', 'event': 'broker_paused'}, {'epoch_ms': '1790400226227', 'event': 'broker_unpaused'}]

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
