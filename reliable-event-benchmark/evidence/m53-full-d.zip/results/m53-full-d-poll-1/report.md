# Benchmark m53-full-d-poll-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3673.566714781819
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 227.8682921271505; steady 20–80% event timestamps: 233.55647232817
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 20084.5, 'p95_ms': 39112.0, 'p99_ms': 41000.01}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 17288.7653, 'max_ms': 171.0574, 'mean_ms': 1.72887653}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 201974065.0, 'max_ms': 41469.0, 'mean_ms': 20197.4065}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 40.10888888888889 / 48.22; max connected/running threads: 17.0 / 8.0
- Publisher memory max (bytes): 324796416.0; MySQL block I/O first/last: ['499MB / 15.1GB', '500MB / 15.4GB']; Broker block I/O first/last: ['775MB / 7.23GB', '780MB / 7.42GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
