# Benchmark m53-full-d-poll-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3332.5827246176586
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 226.21875353466802; steady 20–80% event timestamps: 233.27502429543244
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 20131.5, 'p95_ms': 39254.05, 'p99_ms': 41092.0}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16860.2955, 'max_ms': 160.0545, 'mean_ms': 1.68602955}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 203102398.0, 'max_ms': 41528.0, 'mean_ms': 20310.2398}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 36.995555555555555 / 46.4; max connected/running threads: 33.0 / 10.0
- Publisher memory max (bytes): 325115904.0; MySQL block I/O first/last: ['500MB / 16.8GB', '500MB / 17.2GB']; Broker block I/O first/last: ['780MB / 10.1GB', '780MB / 10.4GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
