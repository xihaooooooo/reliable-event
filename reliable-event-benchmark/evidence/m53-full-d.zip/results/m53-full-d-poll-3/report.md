# Benchmark m53-full-d-poll-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3059.533441954929
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 232.6717699341539; steady 20–80% event timestamps: 233.77483443708607
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 19807.0, 'p95_ms': 37535.899999999914, 'p99_ms': 39514.01}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 18708.8293, 'max_ms': 192.2028, 'mean_ms': 1.87088293}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 198493212.0, 'max_ms': 40036.0, 'mean_ms': 19849.3212}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 36.23 / 50.92; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 385953792.0; MySQL block I/O first/last: ['500MB / 18.6GB', '500MB / 18.9GB']; Broker block I/O first/last: ['780MB / 12.8GB', '780MB / 12.9GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
