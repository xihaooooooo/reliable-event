# Benchmark m53-full-d-queue-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3341.874831214434
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.45916404120937; steady 20–80% event timestamps: 48.93981405969662
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100031.5, 'p95_ms': 189699.04999999932, 'p99_ms': 197637.1800000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 16967.4611, 'max_ms': 194.3928, 'mean_ms': 1.69674611}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1000207817.0, 'max_ms': 199625.0, 'mean_ms': 100020.7817}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 9.999444444444444 / 13.36; max connected/running threads: 33.0 / 10.0
- Publisher memory max (bytes): 427515904.0; MySQL block I/O first/last: ['500MB / 16.1GB', '500MB / 16.4GB']; Broker block I/O first/last: ['780MB / 8.82GB', '780MB / 9.61GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
