# Benchmark m53-full-d-queue-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3573.2034326193166
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.371500794881165; steady 20–80% event timestamps: 48.988554915182284
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100537.5, 'p95_ms': 190152.89999999932, 'p99_ms': 198100.0500000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 18172.3299, 'max_ms': 215.3865, 'mean_ms': 1.8172329900000002}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1005501262.0, 'max_ms': 200070.0, 'mean_ms': 100550.1262}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.90235294117647 / 13.02; max connected/running threads: 33.0 / 9.0
- Publisher memory max (bytes): 433270784.0; MySQL block I/O first/last: ['500MB / 17.8GB', '500MB / 18.2GB']; Broker block I/O first/last: ['780MB / 11.5GB', '780MB / 12.3GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
