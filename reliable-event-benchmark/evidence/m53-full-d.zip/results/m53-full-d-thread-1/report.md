# Benchmark m53-full-d-thread-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3365.046881160139
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.435202807919524; steady 20–80% event timestamps: 48.934626079440285
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100109.0, 'p95_ms': 189738.7499999993, 'p99_ms': 197692.4700000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 22589.3933, 'max_ms': 318.4879, 'mean_ms': 2.25893933}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1001248193.0, 'max_ms': 199642.0, 'mean_ms': 100124.8193}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.549722222222222 / 33.15; max connected/running threads: 24.0 / 9.0
- Publisher memory max (bytes): 370991104.0; MySQL block I/O first/last: ['500MB / 15.8GB', '500MB / 16.1GB']; Broker block I/O first/last: ['780MB / 7.98GB', '780MB / 8.81GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
