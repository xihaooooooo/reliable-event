# Benchmark m53-full-d-thread-2

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3894.1085953179263
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.27831901798166; steady 20–80% event timestamps: 48.9023257330052
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100847.5, 'p95_ms': 190715.0499999993, 'p99_ms': 198676.5700000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 21645.5351, 'max_ms': 265.8793, 'mean_ms': 2.16455351}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1008830776.0, 'max_ms': 200655.0, 'mean_ms': 100883.0776}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 10.665555555555555 / 49.92; max connected/running threads: 18.0 / 2.0
- Publisher memory max (bytes): 383299584.0; MySQL block I/O first/last: ['500MB / 17.6GB', '500MB / 17.8GB']; Broker block I/O first/last: ['780MB / 10.9GB', '780MB / 11.5GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
