# Benchmark m53-full-d-thread-3

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3630.2400154967686
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.46748255034553; steady 20–80% event timestamps: 48.96337334062222
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100136.5, 'p95_ms': 189822.9999999993, 'p99_ms': 197798.5200000002}
- Sender attempts: {'success': 10000}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 21493.4627, 'max_ms': 262.7253, 'mean_ms': 2.14934627}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1001138252.0, 'max_ms': 199775.0, 'mean_ms': 100113.8252}
- Broker messages: 10000; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 9.559722222222222 / 12.98; max connected/running threads: 33.0 / 16.0
- Publisher memory max (bytes): 382521344.0; MySQL block I/O first/last: ['500MB / 19.3GB', '500MB / 19.6GB']; Broker block I/O first/last: ['780MB / 13.1GB', '792MB / 13.4GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
