# Benchmark m53-full-d-unknown-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 10000 / 10000; Outbox rows: 10000
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 10000, '3': 0, '4': 0}; conserved: True
- Registration events/s: 3430.349329623982
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 49.22834568144338; steady 20–80% event timestamps: 49.35357589315087
- First availability to PUBLISHED timestamp difference (ms): {'samples': 10000, 'p50_ms': 100682.5, 'p95_ms': 190654.0, 'p99_ms': 198619.01}
- Sender attempts: {'success': 10000, 'failure': 1}; failure types: {'RESULT_UNKNOWN': 1}; failure rate: 9.999000099990002e-05
- Sender duration by outcome (count/total/mean/max ms): {'success': {'count': 10000, 'total_ms': 17343.1383, 'max_ms': 167.6885, 'mean_ms': 1.7343138299999998}, 'non_retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}, 'unknown': {'count': 1, 'total_ms': 159.0696, 'max_ms': 159.0696, 'mean_ms': 159.0696}, 'retryable': {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'mean_ms': None}}
- First availability to successful receipt timer: {'count': 10000, 'total_ms': 1002185594.0, 'max_ms': 200615.0, 'mean_ms': 100218.5594}
- Broker messages: 10001; complete coverage: True; duplicate identities: 1; duplicate rate: 9.999000099990002e-05
- MySQL CPU avg/max (% of one CPU): 10.939142857142857 / 13.96; max connected/running threads: 33.0 / 8.0
- Publisher memory max (bytes): 354320384.0; MySQL block I/O first/last: ['500MB / 20.8GB', '500MB / 21.1GB']; Broker block I/O first/last: ['792MB / 14.5GB', '792MB / 14.7GB']
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
