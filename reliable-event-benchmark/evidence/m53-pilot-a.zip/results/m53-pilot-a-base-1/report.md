# Benchmark m53-pilot-a-base-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 100 / 100; Outbox rows: 100
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 100, '3': 0, '4': 0}; conserved: True
- Registration events/s: 446.9525434728391
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 59.20663114268798; steady 20–80% event timestamps: 72.87933094384708
- First availability to PUBLISHED timestamp difference (ms): {'samples': 100, 'p50_ms': 1290.0, 'p95_ms': 1684.1, 'p99_ms': 1696.01}
- Sender attempts: {'success': 100}; failure types: {}; failure rate: 0.0
- Sender duration by outcome (count/total/mean/max ms): {}
- First availability to successful receipt timer: {'count': 0, 'total_ms': 0, 'max_ms': None, 'mean_ms': None}
- Broker messages: 100; complete coverage: True; duplicate identities: 0; duplicate rate: 0.0
- MySQL CPU avg/max (% of one CPU): 3.175 / 3.59; max connected/running threads: 17.0 / None
- Publisher memory max (bytes): None; MySQL block I/O first/last: [None, None]; Broker block I/O first/last: [None, None]
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
