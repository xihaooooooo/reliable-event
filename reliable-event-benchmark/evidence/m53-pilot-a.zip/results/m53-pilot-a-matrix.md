# M5.3 matrix m53-pilot-a

Each row in the CSV is one run. P99 values remain per-run values.

- baseline: 1/1 valid; median full-drain events/s: 59.20663114268798
- multi: 1/1 valid; median full-drain events/s: 54.3773790103317
- unknown: 1/1 valid; median full-drain events/s: 35.52397868561279

See each run directory for metadata, event samples, Broker identities and EXPLAIN plans.
