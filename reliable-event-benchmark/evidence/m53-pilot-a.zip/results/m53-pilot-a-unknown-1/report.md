# Benchmark m53-pilot-a-unknown-1

All rates and latency values below are derived from the adjacent raw files. The PUBLISHED timestamp precedes the database commit and is not a precise commit time.

- Registered: 100 / 100; Outbox rows: 100
- Final states (0/1/2/3/4): {'0': 0, '1': 0, '2': 100, '3': 0, '4': 0}; conserved: True
- Registration events/s: 486.6850276704772
- Publication events/s, first batch commit return to last PUBLISHED timestamp: 35.52397868561279; steady 20–80% event timestamps: 72.96650717703349
- First availability to PUBLISHED timestamp difference (ms): {'samples': 100, 'p50_ms': 1866.5, 'p95_ms': 1924.05, 'p99_ms': 1944.1900000000053}
- Sender attempts: {'success': 100, 'failure': 1}; failure types: {'RESULT_UNKNOWN': 1}; failure rate: 0.009900990099009901
- Sender duration by outcome (count/total/mean/max ms): {}
- First availability to successful receipt timer: {'count': 0, 'total_ms': 0, 'max_ms': None, 'mean_ms': None}
- Broker messages: 101; complete coverage: True; duplicate identities: 1; duplicate rate: 0.009900990099009901
- MySQL CPU avg/max (% of one CPU): 1.025 / 1.52; max connected/running threads: 17.0 / None
- Publisher memory max (bytes): None; MySQL block I/O first/last: [None, None]; Broker block I/O first/last: [None, None]
- InnoDB row lock waits/time deltas: 0.0 / 0.0 ms
- Fault timeline (epoch ms): []

See metadata.json for configuration and environment, samples.csv for time series, events.csv for event-level data, messages.csv for Broker identities, and explain-*.txt for query plans.
